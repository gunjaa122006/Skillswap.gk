
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Search, Star, MapPin, Clock, Users } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
// Dummy profiles for display
const dummyProfiles = [
  {
    id: 'dummy-1',
    name: 'Sarah Chen',
    location: 'San Francisco, CA',
    avatar_url: null,
    skills_offered: ['React', 'JavaScript', 'UI/UX Design'],
    skills_wanted: ['Python', 'Data Science', 'Machine Learning'],
    availability: 'Evenings & Weekends',
    rating: 4.8,
    is_public: true
  },
  {
    id: 'dummy-2',
    name: 'Marcus Johnson',
    location: 'Austin, TX',
    avatar_url: null,
    skills_offered: ['Python', 'Django', 'Data Analysis'],
    skills_wanted: ['React', 'Frontend Development', 'CSS'],
    availability: 'Weekdays',
    rating: 4.9,
    is_public: true
  },
  {
    id: 'dummy-3',
    name: 'Elena Rodriguez',
    location: 'New York, NY',
    avatar_url: null,
    skills_offered: ['Graphic Design', 'Adobe Creative Suite', 'Branding'],
    skills_wanted: ['Web Development', 'JavaScript', 'WordPress'],
    availability: 'Flexible',
    rating: 4.7,
    is_public: true
  },
  {
    id: 'dummy-4',
    name: 'David Kim',
    location: 'Seattle, WA',
    avatar_url: null,
    skills_offered: ['Node.js', 'AWS', 'DevOps'],
    skills_wanted: ['Mobile Development', 'React Native', 'iOS'],
    availability: 'Weekends',
    rating: 4.6,
    is_public: true
  }
];

// Profiles state will be fetched from Supabase

const Index = () => {
  // Removed theme context
  const [searchTerm, setSearchTerm] = useState('');
  const [profiles, setProfiles] = useState<any[]>([]);
  const [filteredProfiles, setFilteredProfiles] = useState<any[]>([]);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [requestedProfiles, setRequestedProfiles] = useState<string[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const profilesPerPage = 8;
  const navigate = useNavigate();

  useEffect(() => {
    // Check if user is logged in (mock implementation)
    const authToken = localStorage.getItem('authToken');
    setIsLoggedIn(!!authToken);
  }, []);

  useEffect(() => {
    // Fetch public profiles from Supabase and combine with dummy profiles
    const fetchProfiles = async () => {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('is_public', true);
      let allProfiles = [...dummyProfiles];
      if (!error && data) {
        allProfiles = [...dummyProfiles, ...data];
      }
      setProfiles(allProfiles);
      setFilteredProfiles(allProfiles);
    };
    fetchProfiles();
  }, []);

  useEffect(() => {
    const filtered = profiles.filter(profile =>
      (profile.skills_offered || []).some((skill: string) => 
        skill.toLowerCase().includes(searchTerm.toLowerCase())
      ) ||
      (profile.skills_wanted || []).some((skill: string) => 
        skill.toLowerCase().includes(searchTerm.toLowerCase())
      ) ||
      (profile.name || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (profile.location || '').toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredProfiles(filtered);
    setCurrentPage(1); // Reset to first page on search
  }, [searchTerm, profiles]);

  const handleRequest = (profileId: string) => {
    if (!isLoggedIn) {
      navigate('/login');
      return;
    }
    setRequestedProfiles((prev) => [...prev, profileId]);
    // Handle swap request logic
    console.log(`Requesting swap with user ${profileId}`);
  };

  return (
    <div style={{ minHeight: '100vh', width: '100vw' }}>
      {/* Spline background iframe */}
      <iframe
        src="https://my.spline.design/worldplanet-1ftcIYSbc96uqI0pbwVTIXEa/"
        frameBorder="0"
        width="100%"
        height="100%"
        style={{ position: 'absolute', top: 0, left: 0, width: '100vw', height: '100vh', zIndex: 0, pointerEvents: 'none' }}
        title="Spline Background"
      />
      {/* Main content overlay */}
      <div style={{ position: 'relative', zIndex: 1, minHeight: '100vh' }}>
        {/* Header */}
        <header className="bg-white shadow-sm border-b transition-colors">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center space-x-2">
                <Users className="h-8 w-8 text-blue-600" />
                <h1 className="text-2xl font-bold text-blue-900">SkillSwap</h1>
              </div>
              {/* Removed dark/light toggle button */}
              <nav className="flex items-center space-x-4">
                <Button variant="ghost" className="text-blue-400" onClick={() => navigate('/')}>Home</Button>
                {isLoggedIn ? (
                  <>
                    <Button variant="ghost" className="text-blue-400" onClick={() => navigate('/profile')}>Profile</Button>
                    <Button
                      variant="ghost"
                      className="text-blue-400"
                      onClick={() => navigate('/requests', { state: { sentProfiles: filteredProfiles.filter(p => requestedProfiles.includes(p.id)) } })}
                    >
                      Requests
                    </Button>
                    <Button variant="outline" className="text-blue-400 border-gray-300" onClick={() => {
                      localStorage.removeItem('authToken');
                      setIsLoggedIn(false);
                    }}>Logout</Button>
                  </>
                ) : (
                  <>
                    <Button variant="ghost" className="text-blue-400" onClick={() => navigate('/login')}>Login</Button>
                    <Button className="text-blue-400" onClick={() => navigate('/login')}>Sign Up</Button>
                  </>
                )}
              </nav>
            </div>
          </div>
        </header>

        {/* Hero Section */}
        <section className="bg-black py-16 rounded-xl shadow-md">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center bg-purple-500 rounded-xl shadow-md">
            <h2 className="text-4xl font-bold text-blue-900 mb-4">
              Exchange Skills, Grow Together
            </h2>
            <p className="text-xl text-blue-800 mb-8 max-w-3xl mx-auto">
              Connect with peers to trade skills and knowledge. Teach what you know, learn what you need.
            </p>
            {/* Search Bar */}
            <div className="relative max-w-2xl mx-auto mb-8">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-blue-400 h-5 w-5" />
              <Input
                type="text"
                placeholder="Search by skills, name, or location..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-3 text-lg w-full rounded-full border-2 border-gray-200 focus:border-blue-500"
              />
            </div>
          </div>
        </section>

        {/* Profiles Grid with Pagination */}
        <section className="py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center mb-8">
              <h3 className="text-2xl font-bold text-blue-900">Available Skills</h3>
              <p className="text-blue-900">{filteredProfiles.length} profiles found</p>
            </div>
            {/* Pagination logic */}
            {filteredProfiles.length > 0 ? (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {filteredProfiles
                    .slice((currentPage - 1) * profilesPerPage, currentPage * profilesPerPage)
                    .map((profile) => (
                      <Card key={profile.id} className="hover:shadow-lg transition-shadow duration-300 bg-white">
                        <CardHeader className="pb-4">
                          <div className="flex items-center space-x-3">
                            <Avatar className="h-12 w-12">
                              <AvatarImage src={profile.avatar_url || '/api/placeholder/150/150'} alt={profile.name} />
                              <AvatarFallback>{profile.name?.split(' ').map((n: string) => n[0]).join('')}</AvatarFallback>
                            </Avatar>
                            <div className="flex-1">
                              <CardTitle className="text-lg text-blue-500">{profile.name}</CardTitle>
                              <div className="flex items-center text-sm text-blue-500">
                                <MapPin className="h-3 w-3 mr-1" />
                                {profile.location}
                              </div>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <div>
                            <h4 className="font-semibold text-green-700 mb-2">Offers</h4>
                            <div className="flex flex-wrap gap-1">
                              {(profile.skills_offered || []).map((skill: string, index: number) => (
                                <Badge key={index} variant="secondary" className="bg-green-100 text-green-800">
                                  {skill}
                                </Badge>
                              ))}
                            </div>
                          </div>
                          <div>
                            <h4 className="font-semibold text-blue-700 mb-2">Wants</h4>
                            <div className="flex flex-wrap gap-1">
                              {(profile.skills_wanted || []).map((skill: string, index: number) => (
                                <Badge key={index} variant="outline" className="border-blue-200 text-blue-700">
                                  {skill}
                                </Badge>
                              ))}
                            </div>
                          </div>
                          <div className="flex items-center justify-between text-sm text-blue-600">
                            <div className="flex items-center">
                              <Clock className="h-3 w-3 mr-1" />
                              {profile.availability}
                            </div>
                            <div className="flex items-center">
                              <Star className="h-3 w-3 mr-1 fill-yellow-400 text-yellow-400" />
                              {profile.rating}
                            </div>
                          </div>
                          <Button 
                            className={`w-full ${isLoggedIn ? requestedProfiles.includes(profile.id) ? 'bg-gray-800 text-white' : 'bg-gray-800 text-white' : ''}`}
                            onClick={() => handleRequest(profile.id)}
                            disabled={!isLoggedIn || requestedProfiles.includes(profile.id)}
                            variant={isLoggedIn ? "default" : "secondary"}
                          >
                            {isLoggedIn
                              ? requestedProfiles.includes(profile.id)
                                ? "Request sent"
                                : "Request Swap"
                              : "Login to Request"}
                          </Button>
                        </CardContent>
                      </Card>
                    ))}
                </div>
                {/* Pagination Controls */}
                <div className="mt-8 flex justify-center">
                  <nav aria-label="pagination" className="flex items-center gap-2">
                    <button
                      className="px-3 py-2 rounded-md text-blue-500 bg-white border border-gray-200 disabled:opacity-50"
                      onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                      disabled={currentPage === 1}
                    >
                      Previous
                    </button>
                    {Array.from({ length: Math.ceil(filteredProfiles.length / profilesPerPage) }, (_, i) => i + 1).map((page) => (
                      <button
                        key={page}
                        className={`px-3 py-2 rounded-md border text-blue-500 bg-white border-gray-200 transition-colors
                          ${currentPage === page ? 'font-bold border-blue-500 bg-blue-50 text-blue-700' : ''}`}
                        onClick={() => setCurrentPage(page)}
                      >
                        {page}
                      </button>
                    ))}
                    <button
                      className="px-3 py-2 rounded-md text-blue-500 bg-white border border-gray-200 disabled:opacity-50"
                      onClick={() => setCurrentPage((p) => Math.min(Math.ceil(filteredProfiles.length / profilesPerPage), p + 1))}
                      disabled={currentPage === Math.ceil(filteredProfiles.length / profilesPerPage)}
                    >
                      Next
                    </button>
                  </nav>
                </div>
              </>
            ) : (
              <div className="text-center text-blue-500">No profiles found.</div>
            )}
          </div>
        </section>
      </div>
    </div>
  );
};

export default Index;
