
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Users, Camera, Plus, X, Save, RotateCcw } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

const Profile = () => {
  const [profile, setProfile] = useState({
    name: '',
    email: '',
    location: '',
    avatar: '',
    skillsOffered: [] as string[],
    skillsWanted: [] as string[],
    availability: '',
    visibility: 'public',
    bio: ''
  });
  
  const [newSkillOffered, setNewSkillOffered] = useState('');
  const [newSkillWanted, setNewSkillWanted] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [originalProfile, setOriginalProfile] = useState(profile);
  
  const navigate = useNavigate();

  useEffect(() => {
    // Check if user is logged in
    const authToken = localStorage.getItem('authToken');
    if (!authToken) {
      navigate('/login');
      return;
    }

    // Load user profile data
    const userName = localStorage.getItem('userName') || '';
    const userEmail = localStorage.getItem('userEmail') || '';
    
    const savedProfile = {
      name: userName,
      email: userEmail,
      location: 'San Francisco, CA',
      avatar: '/api/placeholder/150/150',
      skillsOffered: ['React', 'JavaScript', 'UI/UX Design'],
      skillsWanted: ['Python', 'Data Science'],
      availability: 'evenings',
      visibility: 'public',
      bio: 'Passionate developer looking to expand my skills through meaningful exchanges.'
    };
    
    setProfile(savedProfile);
    setOriginalProfile(savedProfile);
  }, [navigate]);

  const addSkillOffered = () => {
    if (newSkillOffered.trim() && !profile.skillsOffered.includes(newSkillOffered.trim())) {
      setProfile({
        ...profile,
        skillsOffered: [...profile.skillsOffered, newSkillOffered.trim()]
      });
      setNewSkillOffered('');
    }
  };

  const addSkillWanted = () => {
    if (newSkillWanted.trim() && !profile.skillsWanted.includes(newSkillWanted.trim())) {
      setProfile({
        ...profile,
        skillsWanted: [...profile.skillsWanted, newSkillWanted.trim()]
      });
      setNewSkillWanted('');
    }
  };

  const removeSkillOffered = (skill: string) => {
    setProfile({
      ...profile,
      skillsOffered: profile.skillsOffered.filter(s => s !== skill)
    });
  };

  const removeSkillWanted = (skill: string) => {
    setProfile({
      ...profile,
      skillsWanted: profile.skillsWanted.filter(s => s !== skill)
    });
  };

  const handleSave = () => {
    // Save profile logic
    localStorage.setItem('userProfile', JSON.stringify(profile));
    setOriginalProfile(profile);
    setIsEditing(false);
    toast.success('Profile updated successfully!');
  };

  const handleDiscard = () => {
    setProfile(originalProfile);
    setIsEditing(false);
    toast.info('Changes discarded');
  };

  return (
    <div style={{ minHeight: '100vh', width: '100vw', position: 'relative' }}>
      {/* Spline background iframe */}
      <iframe
        src="https://my.spline.design/worldplanet-1ftcIYSbc96uqI0pbwVTIXEa/"
        frameBorder="0"
        width="100%"
        height="100%"
        style={{ position: 'absolute', top: 0, left: 0, width: '100vw', height: '100vh', zIndex: 0, pointerEvents: 'none' }}
        title="Spline Background"
      />
      {/* Main content overlay */}
      <div style={{ position: 'relative', zIndex: 1, minHeight: '100vh' }}>
        {/* Header */}
        <header className="bg-blue shadow-sm border-b">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center space-x-2">
                <Users className="h-8 w-8 text-blue-600" />
                <h1 className="text-2xl font-bold text-blue-900">SkillSwap</h1>
              </div>
              <nav className="flex items-center space-x-4">
                <Button variant="ghost" onClick={() => navigate('/')}>Home</Button>
                <Button variant="ghost" onClick={() => navigate('/requests')}>Requests</Button>
                <Button variant="outline" onClick={() => {
                  localStorage.removeItem('authToken');
                  navigate('/');
                }}>Logout</Button>
              </nav>
            </div>
          </div>
        </header>

        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold text-blue-900">My Profile</h2>
            <div className="space-x-2">
              {isEditing ? (
                <>
                  <Button variant="outline" onClick={handleDiscard}>
                    <RotateCcw className="h-4 w-4 mr-2" />
                    Discard
                  </Button>
                  <Button onClick={handleSave}>
                    <Save className="h-4 w-4 mr-2" />
                    Save Changes
                  </Button>
                </>
              ) : (
                <Button onClick={() => setIsEditing(true)}>
                  Edit Profile
                </Button>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Profile Picture and Basic Info */}
            <Card className="lg:col-span-1">
              <CardHeader>
                <CardTitle>Profile Picture</CardTitle>
              </CardHeader>
              <CardContent className="text-center space-y-4">
                <div className="relative inline-block">
                  <Avatar className="h-32 w-32 mx-auto">
                    <AvatarImage src={profile.avatar} alt={profile.name} />
                    <AvatarFallback className="text-2xl">
                      {profile.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  {isEditing && (
                    <Button
                      size="sm"
                      className="absolute bottom-0 right-0 rounded-full"
                      disabled
                    >
                      <Camera className="h-4 w-4" />
                    </Button>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="visibility">Profile Visibility</Label>
                  <RadioGroup
                    value={profile.visibility}
                    onValueChange={(value) => setProfile({...profile, visibility: value})}
                    disabled={!isEditing}
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="public" id="public" />
                      <Label htmlFor="public">Public</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="private" id="private" />
                      <Label htmlFor="private">Private</Label>
                    </div>
                  </RadioGroup>
                </div>
              </CardContent>
            </Card>

            {/* Main Profile Info */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Personal Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    <Input
                      id="name"
                      value={profile.name}
                      onChange={(e) => setProfile({...profile, name: e.target.value})}
                      disabled={!isEditing}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={profile.email}
                      onChange={(e) => setProfile({...profile, email: e.target.value})}
                      disabled={!isEditing}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="location">Location</Label>
                    <Input
                      id="location"
                      value={profile.location}
                      onChange={(e) => setProfile({...profile, location: e.target.value})}
                      disabled={!isEditing}
                      placeholder="City, State"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="availability">Availability</Label>
                    <Select
                      value={profile.availability}
                      onValueChange={(value) => setProfile({...profile, availability: value})}
                      disabled={!isEditing}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select availability" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="weekdays">Weekdays</SelectItem>
                        <SelectItem value="weekends">Weekends</SelectItem>
                        <SelectItem value="evenings">Evenings</SelectItem>
                        <SelectItem value="flexible">Flexible</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="bio">Bio</Label>
                  <Textarea
                    id="bio"
                    value={profile.bio}
                    onChange={(e) => setProfile({...profile, bio: e.target.value})}
                    disabled={!isEditing}
                    placeholder="Tell others about yourself and what you're looking for..."
                    rows={3}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Skills Section */}
            <Card className="lg:col-span-3">
              <CardHeader>
                <CardTitle>Skills</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Skills Offered */}
                <div className="space-y-3">
                  <Label className="text-base font-semibold text-green-700">Skills I Offer</Label>
                  <div className="flex flex-wrap gap-2">
                    {profile.skillsOffered.map((skill, index) => (
                      <Badge key={index} variant="secondary" className="bg-green-100 text-green-800">
                        {skill}
                        {isEditing && (
                          <button
                            onClick={() => removeSkillOffered(skill)}
                            className="ml-2 text-green-600 hover:text-green-800"
                          >
                            <X className="h-3 w-3" />
                          </button>
                        )}
                      </Badge>
                    ))}
                  </div>
                  {isEditing && (
                    <div className="flex gap-2">
                      <Input
                        placeholder="Add a skill you can teach"
                        value={newSkillOffered}
                        onChange={(e) => setNewSkillOffered(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && addSkillOffered()}
                      />
                      <Button onClick={addSkillOffered}>
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                  )}
                </div>

                {/* Skills Wanted */}
                <div className="space-y-3">
                  <Label className="text-base font-semibold text-blue-700">Skills I Want to Learn</Label>
                  <div className="flex flex-wrap gap-2">
                    {profile.skillsWanted.map((skill, index) => (
                      <Badge key={index} variant="outline" className="border-blue-200 text-blue-700">
                        {skill}
                        {isEditing && (
                          <button
                            onClick={() => removeSkillWanted(skill)}
                            className="ml-2 text-blue-600 hover:text-blue-800"
                          >
                            <X className="h-3 w-3" />
                          </button>
                        )}
                      </Badge>
                    ))}
                  </div>
                  {isEditing && (
                    <div className="flex gap-2">
                      <Input
                        placeholder="Add a skill you want to learn"
                        value={newSkillWanted}
                        onChange={(e) => setNewSkillWanted(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && addSkillWanted()}
                      />
                      <Button onClick={addSkillWanted}>
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
