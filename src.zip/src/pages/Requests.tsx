
import { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Users, Clock, CheckCircle, XCircle, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

interface SwapRequest {
  id: number;
  requesterName: string;
  requesterAvatar: string;
  skillOffered: string;
  skillWanted: string;
  message: string;
  status: 'pending' | 'accepted' | 'rejected';
  date: string;
  type: 'sent' | 'received';
}

const mockRequests: SwapRequest[] = [
  {
    id: 1,
    requesterName: 'Marcus Johnson',
    requesterAvatar: '/api/placeholder/150/150',
    skillOffered: 'Python',
    skillWanted: 'React',
    message: 'Hi! I\'d love to help you learn Python in exchange for React knowledge. I have 3 years of experience with Django and data analysis.',
    status: 'pending',
    date: '2024-01-15',
    type: 'received'
  },
  {
    id: 2,
    requesterName: 'Elena Rodriguez',
    requesterAvatar: '/api/placeholder/150/150',
    skillOffered: 'Graphic Design',
    skillWanted: 'JavaScript',
    message: 'I can help you with graphic design and branding in exchange for JavaScript tutoring. Looking forward to learning!',
    status: 'accepted',
    date: '2024-01-12',
    type: 'received'
  },
  {
    id: 3,
    requesterName: 'David Kim',
    requesterAvatar: '/api/placeholder/150/150',
    skillOffered: 'UI/UX Design',
    skillWanted: 'Node.js',
    message: 'Hi David! I\'d like to exchange UI/UX design knowledge for Node.js and AWS expertise.',
    status: 'pending',
    date: '2024-01-14',
    type: 'sent'
  },
  {
    id: 4,
    requesterName: 'Sarah Chen',
    requesterAvatar: '/api/placeholder/150/150',
    skillOffered: 'React',
    skillWanted: 'Machine Learning',
    message: 'I can teach React and frontend development. Would love to learn ML basics from you!',
    status: 'rejected',
    date: '2024-01-10',
    type: 'sent'
  }
];

const Requests = () => {
  const [requests, setRequests] = useState<SwapRequest[]>(mockRequests);
  const navigate = useNavigate();
  const location = useLocation();
  const sentProfiles = location.state?.sentProfiles || [];

  useEffect(() => {
    // Check if user is logged in
    const authToken = localStorage.getItem('authToken');
    if (!authToken) {
      navigate('/login');
    }
  }, [navigate]);

  const handleAccept = (requestId: number) => {
    setRequests(requests.map(req => 
      req.id === requestId ? { ...req, status: 'accepted' } : req
    ));
    toast.success('Request accepted!');
  };

  const handleReject = (requestId: number) => {
    setRequests(requests.map(req => 
      req.id === requestId ? { ...req, status: 'rejected' } : req
    ));
    toast.info('Request rejected');
  };

  const handleDelete = (requestId: number) => {
    setRequests(requests.filter(req => req.id !== requestId));
    toast.success('Request deleted');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'accepted': return 'bg-green-100 text-green-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      default: return 'bg-yellow-100 text-yellow-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'accepted': return <CheckCircle className="h-4 w-4" />;
      case 'rejected': return <XCircle className="h-4 w-4" />;
      default: return <Clock className="h-4 w-4" />;
    }
  };

  const receivedRequests = requests.filter(req => req.type === 'received');
  const sentRequests = requests.filter(req => req.type === 'sent');

  const RequestCard = ({ request }: { request: SwapRequest }) => (
    <Card className="mb-4">
      <CardContent className="p-6">
        <div className="flex items-start space-x-4">
          <Avatar className="h-12 w-12">
            <AvatarImage src={request.requesterAvatar} alt={request.requesterName} />
            <AvatarFallback>{request.requesterName.split(' ').map(n => n[0]).join('')}</AvatarFallback>
          </Avatar>
          
          <div className="flex-1 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-lg">{request.requesterName}</h3>
              <Badge className={getStatusColor(request.status)}>
                {getStatusIcon(request.status)}
                <span className="ml-1 capitalize">{request.status}</span>
              </Badge>
            </div>
            
            <div className="flex flex-wrap gap-2">
              <Badge variant="secondary" className="bg-green-100 text-green-800">
                Offers: {request.skillOffered}
              </Badge>
              <Badge variant="outline" className="border-blue-200 text-blue-700">
                Wants: {request.skillWanted}
              </Badge>
            </div>
            
            <p className="text-blue-600 bg-gray-50 p-3 rounded-lg">
              {request.message}
            </p>
            
            <div className="flex items-center justify-between">
              <span className="text-sm text-blue-500">
                {new Date(request.date).toLocaleDateString()}
              </span>
              
              <div className="flex space-x-2">
                {request.type === 'received' && request.status === 'pending' && (
                  <>
                    <Button 
                      size="sm" 
                      onClick={() => handleAccept(request.id)}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      Accept
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline" 
                      onClick={() => handleReject(request.id)}
                    >
                      Reject
                    </Button>
                  </>
                )}
                
                {(request.status === 'rejected' || request.status === 'accepted') && (
                  <Button 
                    size="sm" 
                    variant="outline" 
                    onClick={() => handleDelete(request.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div style={{ minHeight: '100vh', width: '100vw' }}>
      {/* Spline background iframe */}
      <iframe
        src="https://my.spline.design/worldplanet-1ftcIYSbc96uqI0pbwVTIXEa/"
        frameBorder="0"
        width="100%"
        height="100%"
        style={{ position: 'absolute', top: 0, left: 0, width: '100vw', height: '100vh', zIndex: 0, pointerEvents: 'none' }}
        title="Spline Background"
      />
      {/* Main content overlay */}
      <div style={{ position: 'relative', zIndex: 1, minHeight: '100vh' }}>
        {/* ...existing code... */}
        <header className="bg-white shadow-sm border-b">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center space-x-2">
                <Users className="h-8 w-8 text-blue-600" />
                <h1 className="text-2xl font-bold text-blue-900">SkillSwap</h1>
              </div>
              <nav className="flex items-center space-x-4">
                <Button variant="ghost" onClick={() => navigate('/')}>Home</Button>
                <Button variant="ghost" onClick={() => navigate('/profile')}>Profile</Button>
                <Button variant="outline" onClick={() => {
                  localStorage.removeItem('authToken');
                  navigate('/');
                }}>Logout</Button>
              </nav>
            </div>
          </div>
        </header>

        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-blue-900 mb-2">Swap Requests</h2>
            <p className="text-blue-600">Manage your skill exchange requests</p>
          </div>

          <Tabs defaultValue="received" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="received">
                Received ({receivedRequests.length})
              </TabsTrigger>
              <TabsTrigger value="sent">
                Sent ({sentRequests.length})
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="received" className="mt-6">
              {receivedRequests.length === 0 ? (
                <Card>
                  <CardContent className="p-8 text-center">
                    <div className="text-blue-400 mb-4">
                      <Clock className="h-16 w-16 mx-auto" />
                    </div>
                    <h3 className="text-lg font-semibold text-blue-900 mb-2">No received requests</h3>
                    <p className="text-blue-600">When someone wants to exchange skills with you, their requests will appear here.</p>
                  </CardContent>
                </Card>
              ) : (
                receivedRequests.map(request => (
                  <RequestCard key={request.id} request={request} />
                ))
              )}
            </TabsContent>
            
            <TabsContent value="sent" className="mt-6">
              {/* Show sent profiles from home page first */}
              {sentProfiles.length > 0 && (
                <div className="mb-8">
                  <h3 className="text-xl font-bold text-blue-900 mb-4">Profiles You've Sent Requests To</h3>
                  {sentProfiles.map(profile => (
                    <Card key={profile.id} className="mb-4">
                      <CardContent className="p-6">
                        <div className="flex items-start space-x-4">
                          <Avatar className="h-12 w-12">
                            <AvatarImage src={profile.avatar_url || '/api/placeholder/150/150'} alt={profile.name} />
                            <AvatarFallback>{profile.name?.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1 space-y-3">
                            <div className="flex items-center justify-between">
                              <h3 className="font-semibold text-lg">{profile.name}</h3>
                              <Badge className="bg-yellow-100 text-yellow-800">
                                <Clock className="h-4 w-4" />
                                <span className="ml-1">Request sent</span>
                              </Badge>
                            </div>
                            <div className="flex flex-wrap gap-2">
                              <Badge variant="secondary" className="bg-green-100 text-green-800">
                                Offers: {(profile.skills_offered || []).join(', ')}
                              </Badge>
                              <Badge variant="outline" className="border-blue-200 text-blue-700">
                                Wants: {(profile.skills_wanted || []).join(', ')}
                              </Badge>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-sm text-blue-500">{profile.location}</span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
              {/* Then show mock sent requests */}
              {sentRequests.length === 0 && sentProfiles.length === 0 ? (
                <Card>
                  <CardContent className="p-8 text-center">
                    <div className="text-blue-400 mb-4">
                      <Clock className="h-16 w-16 mx-auto" />
                    </div>
                    <h3 className="text-lg font-semibold text-blue-900 mb-2">No sent requests</h3>
                    <p className="text-blue-600">
                      Browse the <Button variant="link" className="p-0 h-auto" onClick={() => navigate('/')}>home page</Button> to find people to exchange skills with.
                    </p>
                  </CardContent>
                </Card>
              ) : (
                sentRequests.map(request => (
                  <RequestCard key={request.id} request={request} />
                ))
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default Requests;
